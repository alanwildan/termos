
const fs = require('fs')
const chalk = require('chalk')

// Other
global.owner = ['6285793432434']
global.packname = 'xD'
global.author = '@pler.mp4'
global.sessionName = 'session'
global.mess = {
    success: '✓ Success',
    wait: 'Loading...',
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
